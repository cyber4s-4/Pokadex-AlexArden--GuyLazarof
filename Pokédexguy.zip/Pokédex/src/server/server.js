"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const body_parser_1 = require("body-parser");
const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
app.use((0, body_parser_1.json)());
const pokemonList = JSON.parse(fs.readFileSync(__dirname + '/../data.json'));
console.log(__dirname + '/../data.json');
app.use(express.static(__dirname + '/../'));
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname + './../index.html'));
});
app.get('/pokemons', (req, res) => {
    res.send(pokemonList);
});
app.listen(3000, () => {
    console.log('Listening on port 3000');
});
//# sourceMappingURL=server.js.map
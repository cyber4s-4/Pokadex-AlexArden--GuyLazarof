"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Pokemon {
    constructor(parent, pokemonData) {
        this.parent = parent;
        this.pokemonData = pokemonData;
        this.render(parent, pokemonData);
    }
    render(parent, pokemonData) {
        const pokemonDiv = document.createElement('div');
        pokemonDiv.classList.add('pokemon');
        const type = pokemonData.types[0];
        const typeImg = `/img/${type}.png`;
        pokemonDiv.innerHTML = `
     <img src="${pokemonData.image}">   
     <div class="name">${pokemonData.name}</div>
     <div class="heigth">Height: ${pokemonData.height / 10} meter</div>
     <div class="weigth">Weigth: ${pokemonData.weight / 10} kg</div>
     <div class="type"><img src="${typeImg}" />${type}</div>
    `;
        parent.appendChild(pokemonDiv);
    }
}
exports.default = Pokemon;
//# sourceMappingURL=Pokemon.js.map
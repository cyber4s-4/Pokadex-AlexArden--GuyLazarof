"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const Pokemon_1 = __importDefault(require("./Pokemon"));
const container = document.querySelector('.container');
const input = document.querySelector('.input');
const paginationDiv = document.querySelector('.pagination');
const homePageDiv = document.querySelector('.homePage');
const homePageDiv2 = document.querySelector('#homePage2');
const pokemonList = [];
getDataFromServer();
// Get a list of pokemons from API
async function getPokemonList(url) {
    const pokemonList = await fetch(url);
    const listData = await pokemonList.json();
    return listData;
}
// Show searched pokemon or instead show error.
const searchButton = document.querySelector('.search-button');
searchButton.addEventListener('click', () => {
    // Fix container to contain one element
    container.style.width = '200px';
    container.style.position = 'relative';
    container.style.left = '0';
    paginationDiv.style.display = 'none';
    const pokemonsList = getPokemonList('https://pokeapi.co/api/v2/pokemon/?offset=0&limit=151');
    let foundPokemon = false;
    pokemonsList.then((value) => {
        value.results.forEach((item) => {
            if (item.name === input.value.toLowerCase()) {
                container.innerHTML = '';
                renderPokemon(item.url);
                input.value = '';
                foundPokemon = true;
            }
        });
        if (foundPokemon === false) {
            if (input.value === '') {
                showErrorMassage(container, input, 'Please Enter A Pokemon Name! <img src=\'img/research.png\' class=\'notFoundImg\'>');
                return;
            }
            showErrorMassage(container, input, `<u>${input.value}</u> &nbsp Is Not A Pokemon <img src='img/research.png' class='notFoundImg'>`);
        }
    });
});
// Search by key down
input.addEventListener('keyup', () => {
    // Fix container to contain one element
    container.style.width = '200px';
    container.style.position = 'relative';
    container.style.left = '0';
    paginationDiv.style.display = 'none';
    homePageDiv2.style.display = 'none';
    const matchedPokemon = [];
    pokemonList.forEach((pokemon) => {
        if (pokemon.name.includes(input.value.toLowerCase())) {
            matchedPokemon.push(pokemon);
        }
        else {
            container.innerHTML = '';
        }
    });
    matchedPokemon.forEach((pokemon) => {
        renderPokemon(pokemon);
    });
    if (input.value === '') {
        container.innerHTML = '';
    }
});
// Render pokemon
async function renderPokemon(data) {
    const pokemon = new Pokemon_1.default(container, data);
}
// Show all pokemons from server
const allPokemons = document.querySelector('.allPokemons');
allPokemons.addEventListener('click', () => {
    container.innerHTML = '';
    homePageDiv.style.display = 'none';
    homePageDiv2.style.display = 'none';
    // Fix container to contain three elements
    container.style.width = '600px';
    pokemonList.forEach((pokemon) => {
        renderPokemon(pokemon);
    });
});
// Home button functionality
const homeButton = document.querySelector('.homeButton');
homeButton.addEventListener('click', () => {
    location.href = '/';
});
// About button functionality
const aboutButton = document.querySelector('.aboutButton');
aboutButton.addEventListener('click', () => {
    searchButton.style.display = 'none';
    paginationDiv.style.display = 'none';
    input.style.display = 'none';
    homePageDiv.style.display = 'none';
    homePageDiv2.style.display = 'none';
    const aboutContainer = document.createElement('div');
    aboutContainer.className = 'aboutContainer';
    container.innerHTML = '';
    aboutContainer.innerHTML = `
    Hi we are Alex Arden and Guy Lazarof - we love pokemons!
    and we would like to spread that love to other people like you,
    feel free to share our website
    `;
    container.appendChild(aboutContainer);
});
// Pagination function
function pagination(num) {
    const pages = Math.ceil(num / 50);
    for (let i = 0; i < pages; i++) {
        const pageButton = document.createElement('button');
        pageButton.innerHTML = `${i + 1}`;
        pageButton.className = 'p-button';
        pageButton.addEventListener('click', () => {
            container.innerHTML = '';
            homePageDiv.style.display = 'none';
            homePageDiv2.style.display = 'none';
            // Fix container to contain three elements
            container.style.width = '600px';
            for (let j = 0; j < 50; j++) {
                if (pokemonList[i * 50 + j] !== undefined) {
                    renderPokemon(pokemonList[i * 50 + j]);
                }
            }
        });
        paginationDiv.appendChild(pageButton);
    }
}
pagination(800);
// Helper functions
function showErrorMassage(container, input, massage) {
    container.innerHTML = '';
    const notExistsPokemon = document.createElement('div');
    notExistsPokemon.className = 'notFound';
    notExistsPokemon.innerHTML = massage;
    container.appendChild(notExistsPokemon);
    input.value = '';
}
async function getDataFromServer() {
    const dataFromServer = await fetch('/pokemons');
    dataFromServer.json().then((pokemons) => {
        pokemons.forEach((pokemon) => {
            pokemonList.push(pokemon);
        });
    });
}
//# sourceMappingURL=app.js.map